<?php
// Include the database connection file
include('../db_connection.php');

// Check if the application_id is passed in the URL
if (isset($_GET['application_id'])) {
    $application_id = $_GET['application_id'];

    // Fetch the leave application details from the database
    $query = "SELECT * FROM leave_applications WHERE application_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $application_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Fetch the application data
        $application = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success - Leave Application</title>

    <!-- Add CSS styles directly inside the HTML -->
    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fc;
            color: #333;
        }

        /* Main Success Container */
        .success-container {
            width: 60%;
            margin: 100px auto;
            padding: 40px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            color: #fff;
            text-align: center;
        }

        /* Title */
        h1 {
            font-size: 36px;
            color: #e74c3c;
            margin-bottom: 20px;
        }

        /* Details Text */
        p {
            font-size: 18px;
            margin-bottom: 15px;
        }

        /* Supporting Document Link */
        a {
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Buttons */
        .back-button, .home-button {
            background-color: #3498db;
            color: white;
            padding: 14px 24px;
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .back-button:hover, .home-button:hover {
            background-color: #2980b9;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .success-container {
                width: 90%;
                padding: 20px;
            }

            h1 {
                font-size: 28px;
            }

            p {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

    <!-- Success Message Container -->
    <div class="success-container">
        <h1>Leave Application Submitted Successfully</h1>
        <p><strong>Leave Type:</strong> <?php echo $application['leave_type']; ?></p>
        <p><strong>Start Date:</strong> <?php echo $application['start_date']; ?></p>
        <p><strong>End Date:</strong> <?php echo $application['end_date']; ?></p>
        <p><strong>Reason:</strong> <?php echo $application['reason']; ?></p>
        <?php if (!empty($application['supporting_document'])): ?>
        <a href="/LeaveSystem/uploads/<?php echo htmlspecialchars($application['supporting_document']); ?>" target="_blank">View Document</a>
          <?php else: ?>
          No document attached
         <?php endif; ?>
        <p><strong>Status:</strong> <?php echo $application['status']; ?></p>
        
        <!-- Back to Application Button -->
        <button class="back-button" onclick="window.location.href='apply_leave.php'">Back to Application</button>

        <!-- Back to Homepage Button -->
        <a href="../Staff/index.html">
            <button class="home-button">Back to Homepage</button>
        </a>
    </div>

</body>
</html>
<?php
    } else {
        echo "No leave application found.";
    }
    $stmt->close();
} else {
    echo "No application ID provided.";
}

$conn->close();
?>
