<?php
// Include the database connection file
include('../db_connection.php'); 

// Start session to check if the user is logged in
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with LeadMark landing page.">
    <meta name="author" content="Devcrud">
    <title>Apply Leave</title>
    <!-- font icons -->
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + LeadMark main styles -->
	<link rel="stylesheet" href="css/leadmark.css">
	
	 <header class="header">
        <div class="overlay">
         
		

    <!-- Add CSS styles directly inside the HTML -->
    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7fc;
            color: #fff;
        }

        /* Main Container */
        .container {
            width: 100%;
            margin: 100px auto;
            padding: 40px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }

        /* Page Heading */
        h2 {
            text-align: center;
            color: #fff;
            font-size: 32px;
            margin-bottom: 20px;
        }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-size: 18px;
            font-weight: bold;
            color: #fff;
        }

        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ddd;
            box-sizing: border-box;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        /* Submit Button */
        .submit-btn {
            background-color: #e74c3c;
            color: white;
            padding: 14px;
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #c0392b;
        }

        /* File Input Styling */
        input[type="file"] {
            border: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                width: 90%;
                padding: 20px;
            }

            h2 {
                font-size: 26px;
            }
        }


        .container {
            position: relative;
            z-index: 80;
        }
		
    </style>
</head>
<body>

<!-- Background Image -->
<div class="background">
    <div class="container">
        <h2>Apply for Leave</h2>
        <form action="apply_leave_process.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="leave_type">Leave Type</label>
                <select name="leave_type" id="leave_type" required>
                    <option value="annual">Annual</option>
                    <option value="unpaid">Unpaid</option>
                    <option value="maternity_paternity">Maternity/Paternity</option>
                    <option value="public_holiday">Public Holiday</option>
                    <option value="compassionate">Compassionate</option>
                    <option value="other">Other</option>
                </select>
            </div>

            <div class="form-group">
                <label for="start_date">Start Date</label>
                <input type="date" id="start_date" name="start_date" required>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <input type="date" id="end_date" name="end_date" required>
            </div>

            <div class="form-group">
                <label for="reason">Reason</label>
                <textarea id="reason" name="reason" rows="4" required></textarea>
            </div>

            <div class="form-group">
                <label for="supporting_document">Supporting Document (optional)</label>
                <input type="file" id="supporting_document" name="supporting_document">
            </div>

            <div class="form-group">
                <button type="submit" class="submit-btn">Submit Application</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
