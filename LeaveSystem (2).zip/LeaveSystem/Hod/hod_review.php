<?php
// Include the database connection and session management at the top
include('../db_connection.php');
session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch the logged-in staff details and the leave applications grouped by status
$staff_id = $_SESSION['staff_id'];
$query_hod = "SELECT department FROM staff WHERE staff_id = ?";
$stmt_hod = $conn->prepare($query_hod);
$stmt_hod->bind_param("i", $staff_id);
$stmt_hod->execute();
$result_hod = $stmt_hod->get_result();
$hod_data = $result_hod->fetch_assoc();

if (!$hod_data) {
    die("Access denied. Only HODs can access this page.");
}

$department = $hod_data['department'];

// Handle form submission for approving or rejecting leave applications
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['leave_id']) && isset($_POST['status'])) {
        $leave_id = $_POST['leave_id'];
        $status = $_POST['status'];

        // Update leave status in the database
        $update_query = "UPDATE leave_applications SET status = ? WHERE application_id = ?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("si", $status, $leave_id);
        $stmt_update->execute();

        // Redirect back to the page after update
        header("Location: hod_review.php");
        exit();
    }
}

// Base query to fetch all leave applications
$query_all = "SELECT la.*, s.name AS staff_name
              FROM leave_applications la
              JOIN staff s ON la.staff_id = s.staff_id";
$stmt_all = $conn->prepare($query_all);
$stmt_all->execute();
$result_all = $stmt_all->get_result();
$leave_applications = $result_all->fetch_all(MYSQLI_ASSOC);

// Close the statement
$stmt_all->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD - Review Leave Applications</title>
    <style>
 
/* General Body Styles */
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f9;
    color: #333;
}

/* Container Styles */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

/* Header Styles */
.header {
    text-align: center;
    margin-bottom: 30px;
}

.header h1 {
    font-size: 2rem;
    color: #e74c3c;
    margin-bottom: 10px;
}

.header p {
    font-size: 1.2rem;
    color: #555;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    background: #ffffff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    border-radius: 8px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #34495e;
    color: #ffffff;
    font-weight: bold;
}

td {
    font-size: 0.9rem;
    color: #555;
}

tr:hover {
    background-color: #f1f1f1;
}

td a {
    color: #3498db;
    text-decoration: none;
    font-weight: bold;
}

td a:hover {
    text-decoration: underline;
}

/* Button Styles */
button, .btn {
    background-color: #e74c3c;
    color: white;
    border: none;
    padding: 10px 15px;
    font-size: 1rem;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
}

button:hover, .btn:hover {
    background-color: #c0392b;
}

/* Search Bar Styles */
.search-bar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
}

.search-bar input {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
    margin-right: 10px;
}

.search-bar button {
    padding: 10px 20px;
    font-size: 1rem;
    background-color: #3498db;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}

.search-bar button:hover {
    background-color: #2980b9;
}

/* Footer Styles */
.footer {
    text-align: center;
    padding: 10px 0;
    margin-top: 20px;
    font-size: 0.9rem;
    color: #777;
}
 </style>
</head>
<body>

<div class="container">
    <h1>Leave Application Review</h1>

    <!-- Status Buttons -->
    <div class="status-buttons">
        <button class="status-button" id="pending-btn">Pending</button>
        <button class="status-button" id="approved-btn">Approved</button>
        <button class="status-button" id="rejected-btn">Rejected</button>
    </div>

    <!-- Leave Applications (All status initially) -->
    <div id="leave-applications-container">
        <?php foreach (['pending', 'approved', 'rejected'] as $status): ?>
            <div class="status-section" id="<?php echo $status; ?>-applications" style="display: none;">
                <h2><?php echo ucfirst($status); ?> Applications</h2>
                <?php 
                // Filter applications by status
                $filtered_applications = array_filter($leave_applications, function($application) use ($status) {
                    return strtolower($application['status']) == $status;
                });

                if (!empty($filtered_applications)): ?>
                    <table class="application-table">
                        <thead>
                            <tr>
							    <th>Application ID</th>
                                <th>Staff Name</th>
                                <th>Leave Type</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Reason</th>
                                <th>Supporting Document</th>
                                <?php if ($status == 'pending'): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($filtered_applications as $application): ?>
                                <tr>
								    <td><?php echo htmlspecialchars($application['application_id']); ?></td>
                                    <td><?php echo htmlspecialchars($application['staff_name']); ?></td>
                                    <td><?php echo htmlspecialchars($application['leave_type']); ?></td>
                                    <td><?php echo htmlspecialchars($application['start_date']); ?></td>
                                    <td><?php echo htmlspecialchars($application['end_date']); ?></td>
                                    <td><?php echo htmlspecialchars($application['reason']); ?></td>
                                    <td>
                                        <?php if (!empty($application['supporting_document'])): ?>
                                            <a href="/LeaveSystem/uploads/<?php echo htmlspecialchars($application['supporting_document']); ?>" target="_blank">View Document</a>
                                        <?php else: ?>
                                            No document attached
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($status == 'pending'): ?>
                                        <td>
                                            <form action="hod_review.php" method="POST">
                                                <input type="hidden" name="leave_id" value="<?php echo $application['application_id']; ?>">
                                                <div class="action-btns">
                                                    <button type="submit" name="status" value="approved" class="action-btn approve-btn">Approve</button>
                                                    <button type="submit" name="status" value="rejected" class="action-btn reject-btn">Reject</button>
                                                </div>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No <?php echo $status; ?> applications.</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Back to Home Button -->
    <a href="../Hod" class="home-button">Back to Dashboard</a>
</div>

<script>
    // JavaScript to handle status button clicks
    document.getElementById("pending-btn").onclick = function() {
        toggleStatusView('pending');
    };
    document.getElementById("approved-btn").onclick = function() {
        toggleStatusView('approved');
    };
    document.getElementById("rejected-btn").onclick = function() {
        toggleStatusView('rejected');
    };

    function toggleStatusView(status) {
        const sections = document.querySelectorAll('.status-section');
        sections.forEach(function(section) {
            section.style.display = 'none';
        });
        document.getElementById(status + '-applications').style.display = 'block';
    }

    // Set default view to Pending
    toggleStatusView('pending');
</script>

</body>
</html>