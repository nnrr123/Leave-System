<?php
// Include the database connection file
include('../db_connection.php');

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php"); // Redirect to login if not logged in
    exit();
}

$staff_id = $_SESSION['staff_id']; // Logged in staff ID

// Fetch the leave applications submitted by the staff
$query = "SELECT * FROM leave_applications WHERE staff_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are any applications
if ($result->num_rows > 0) {
    $applications = $result->fetch_all(MYSQLI_ASSOC); // Fetch all applications
} else {
    $applications = [];
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Application Status</title>

    <!-- Add CSS styles -->
    <style>
       
/* General Body Styles */
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f9;
    color: #333;
}

/* Container Styles */
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

/* Header Styles */
.header {
    text-align: center;
    margin-bottom: 30px;
}

.header h1 {
    font-size: 2rem;
    color: #e74c3c;
    margin-bottom: 10px;
}

.header p {
    font-size: 1.2rem;
    color: #555;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    background: #ffffff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    border-radius: 8px;
    overflow: hidden;
}

th, td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #34495e;
    color: #ffffff;
    font-weight: bold;
}

td {
    font-size: 0.9rem;
    color: #555;
}

tr:hover {
    background-color: #f1f1f1;
}

td a {
    color: #3498db;
    text-decoration: none;
    font-weight: bold;
}

td a:hover {
    text-decoration: underline;
}

/* Button Styles */
button, .btn {
    background-color: #e74c3c;
    color: white;
    border: none;
    padding: 10px 15px;
    font-size: 1rem;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
}

button:hover, .btn:hover {
    background-color: #c0392b;
}

/* Search Bar Styles */
.search-bar {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
}

.search-bar input {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
    margin-right: 10px;
}

.search-bar button {
    padding: 10px 20px;
    font-size: 1rem;
    background-color: #3498db;
    border: none;
    border-radius: 5px;
    color: white;
    cursor: pointer;
}

.search-bar button:hover {
    background-color: #2980b9;
}

/* Footer Styles */
.footer {
    text-align: center;
    padding: 10px 0;
    margin-top: 20px;
    font-size: 0.9rem;
    color: #777;
}
    </style>
</head>
<body>

    <!-- Main Container -->
    <div class="container">
        <h1>Your Leave Application Status</h1>

        <?php if (!empty($applications)): ?>
            <!-- Table to display leave applications -->
            <table>
                <thead>
                    <tr>
                        <th>Leave Type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Reason</th>
                        <th>Supporting Document</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $application): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($application['leave_type']); ?></td>
                            <td><?php echo htmlspecialchars($application['start_date']); ?></td>
                            <td><?php echo htmlspecialchars($application['end_date']); ?></td>
                            <td><?php echo htmlspecialchars($application['reason']); ?></td>
                            <td>
                                <?php if ($application['supporting_document']): ?>
                                    <a href="<?php echo $application['supporting_document']; ?>" target="_blank">View Document</a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td class="status 
                                <?php echo strtolower($application['status']); ?>">
                                <?php echo htmlspecialchars($application['status']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No leave applications found.</p>
        <?php endif; ?>

        <!-- Back to Homepage Button -->
        <a href="../Staff/index.html">
            <button class="home-button">Back to Homepage</button>
        </a>
    </div>

</body>
</html>
