<?php
// Include the database connection file
include('../db_connection.php'); // Ensure this file initializes $conn properly

// Start session to check if the user is logged in
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php"); // Redirect to login if not logged in
    exit();
}

// Get the form data from POST
$leave_type = $_POST['leave_type'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$reason = $_POST['reason'];
$staff_id = $_SESSION['staff_id']; // Get logged in staff ID from session

// Handle file upload if a document is submitted
$supporting_document = null;
if (isset($_FILES['supporting_document']) && $_FILES['supporting_document']['error'] === UPLOAD_ERR_OK) {
    $target_dir = "uploads/"; // Relative to the root folder of the project
    $file_name = basename($_FILES["supporting_document"]["name"]);
    $target_file = $target_dir . $file_name;

    // Check if the file can be uploaded
    if (move_uploaded_file($_FILES["supporting_document"]["tmp_name"], "../" . $target_file)) {
        $supporting_document = $file_name; // Save only the file name in the database
    } else {
        die("Error uploading file.");
    }
}


// Insert the leave application into the database
$query = "INSERT INTO leave_applications (staff_id, leave_type, start_date, end_date, reason, supporting_document, status, created_at)
          VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())";

$stmt = $conn->prepare($query);
$stmt->bind_param("isssss", $staff_id, $leave_type, $start_date, $end_date, $reason, $supporting_document);

if ($stmt->execute()) {
    // Get the application ID of the last inserted row
    $application_id = $stmt->insert_id;

    // Redirect to the success page with the application ID as a URL parameter
    header("Location: success_page.php?application_id=" . $application_id);
    exit(); // Ensure the script ends after the redirect
} else {
    // Handle error if the query fails
    echo "Error: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>

